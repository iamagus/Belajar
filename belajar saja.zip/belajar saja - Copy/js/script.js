//Toggle class active
const navlist = document.querySelector
('.nav-list');

//ketika menu di klik
document.querySelector('#menu').
onclick = () => {
    navlist.classList.toggle('active');
};

//klik di luar sidebar untuk menghilangkan nav
const menu = document.querySelector('#menu');

document.addEventListener('click', function(e) {
    if (!menu.contains(e.target) && !navlist.contains(e.target)) {
        navlist.classList.remove('active');
    }
});